/* SystemJS module definition */
declare var jQuery:any;
declare var $:any;
declare var module: NodeModule;
interface NodeModule {
  id: string;
}
