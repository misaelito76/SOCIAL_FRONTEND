export var GLOBAL = {
	url: 'http://localhost:3800/api/'
}